package com.jeffguy;
import java.io.*;
import java.util.Vector;

/**
 * Modified to use .bat files as Ini files ;-)
 * IniFile is a class for reading and writing to the windows
 * type of <code>.ini</code> file.
 * The .ini file is a text file with various parts contained in it:
 * <ul>
 * <li>Sections are denoted with the section name in brackets
 * <li>In each section are keys
 * <li>After each key is an equal sign and then the key's value
 * </ul>
 * <p>Here is an example of a typical <code>.ini</code> file:
 * <p><code>rem [SectionName]</code>
 * <br><code>key1=value</code>
 * <br><code>key2=value</code>
 * <br><code>key3=value</code>
 * <p>Turning the cache on will cause the entire file to stay
 * in memory. Turning the cache off will cause the file to be
 * read line by line each time a setting is retrieved. Also, if
 * caching is turned on, all changes will not be saved until
 * the <code>flush()</code> method is called. When caching is
 * turned off, all writes are immediate.
 *
 * @author    Jeff L. Williams (http://www.jeffguy.com/java/)
 * @version   %I%, %G%
 * @since     JDK1.2
 */
public class IniFile {

  private boolean debugOn = false;

  private String      iniFilename;
  private Vector      iniCache = new Vector();
  private boolean     cached = false;
  private boolean     currentlyCached;


  public void setDebug(boolean debug){
    debugOn = debug;
  }

  /**
   * Passes the .ini filename to the object on creation
   *
   * @param filename  the name of the <code>.ini</code> file to use
   * @since           JDK1.2
   */
  public IniFile(String filename) {
    iniFilename = filename;
    if (debugOn){
      System.out.println("Class IniFile with debugOn: loading "+filename);
    }

  }

  /**
   * Passes the .ini filename to the object on creation
   *
   * @param filename  the name of the <code>.ini</code> file to use
   * @param cached    whether the file is cached in memory or not
   * @since           JDK1.2
   */
  public IniFile(String filename, boolean cached) {
    iniFilename = filename;
    this.cached = cached;
    this.loadCache();
    if (debugOn){
      System.out.println("Class IniFile with debugOn: loading "+filename);
    }
  }

//----------------------------------------------------------------------------

  /**
   * InString finds an string within an existing string
   * starting from a specified location
   *
   * @param   string          the string to be searched
   * @param   search          what to look for in the string
   * @param   startPosition   where to start searching in the string
   * @return  returns an integer that holds the location
   *          to the first occurance found in the string
   *          from the starting position
   * @author  Jeff L. Williams
   */
  private int inString(String string,
                       String search,
                       int startPosition) {

    //Create a variable that will hold the position of the search string
    int pos = 0;

    //If what we are looking for is longer than the original string,
    //then it's not going to be a match and return 0
    if (search.length() > string.length()) {
      pos = 0;

    } else {

      //We can't search past the end of the string so find a stopping point
      int stopPosition = (string.length() - search.length()) + 1;

      //Loop through the positions in the string looking for the criteria
      for (int i = startPosition - 1; i < stopPosition; i++) {
        String sTemp = string.substring(i, i + search.length());

        //If we found a match, break out and return the results
        if (sTemp.compareTo(search) == 0) {
          pos = i + 1;
          break;
        }
      }
    }
    return pos;
  }

//----------------------------------------------------------------------------

  /**
   * Determines if the .ini file is cached in memory or read each
   * time it is called.
   *
   * @param cached    true if the entire .ini file is kept in memory;
   *                  false if the .ini file is not kept in memory
   * @since           JDK1.2
   */
  public void setCachedState(boolean cached) {
    this.cached = cached;
    this.iniCache.clear();
    this.currentlyCached = false;
  }

//----------------------------------------------------------------------------

  /**
   * Returns ture if the .ini file is cached in memory or false if it
   * is read each time the object is called.
   *
   * @param cached    true if the entire .ini file is kept in memory;
   *                  false if the .ini file is not kept in memory
   * @since           JDK1.2
   */
  public boolean getCachedState() {
    return this.cached;
  }

//----------------------------------------------------------------------------

  /**
   * Sets the name of the <code>.ini</code> file the object is using.
   *
   * @param filename  the name of the <code>.ini</code> file to use
   * @since           JDK1.2
   */
  public void setFilename(String filename) {
    iniFilename = filename;
  }

//----------------------------------------------------------------------------

  /**
   * Returns a String that contains the name of the <code>.ini</code>
   * file currently being used.
   *
   * @return          a String that contains the name of the .ini file
   * @since           JDK1.2
   */
  public String getFilename() {
    return iniFilename;
  }

//----------------------------------------------------------------------------

  /**
   * Returns an integer that contains the value for a specified key.
   *
   * @param section       the name of the section in the <code>.ini</code>
   *                      file.
   * @param key           the name of the key in the <code>.ini</code> file.
   * @param defaultValue  the default value for the key.
   * @return              an integer that contains the value for the
   *                      specified key
   * @since               JDK1.2
   */
  public int getSettingInteger(String section,
                               String key,
                               int defaultValue) {

    String s = new String(String.valueOf(defaultValue));

    // Get the value
    String value = getSetting(section, key, s);

    // Convert it into an integer
    try {
      int i = Integer.parseInt(value);
      return i;
    }
    catch(NumberFormatException e) {
      return 0;
    }

  }

//----------------------------------------------------------------------------

  /**
   * Returns a boolean that contains the value for a specified key.
   *
   * @param section       the name of the section in the <code>.ini</code>
   *                      file.
   * @param key           the name of the key in the <code>.ini</code> file.
   *                      If the value of the key is <code>true</code>,
   *                      <code>on</code>, <code>yes</code>, or
   *                      <code>normal</code>, then the boolean value returned
   *                      would be <code>true</code>. All other values will
   *                      return a boolean value of <code>false</code>.
   * @param defaultValue  the default value for the key.
   * @return              a boolean that contains the value for the specified
   *                      key
   * @since               JDK1.2
   */
  public boolean getSettingBoolean(String section,
                                   String key,
                                   boolean defaultValue) {

    String s;
    if (defaultValue) {
      s = "TRUE";
    } else {
      s = "FALSE";
    }

    // Get the value
    String sTemp   = getSetting(section, key, s);
    String sValue  = sTemp.toUpperCase();
    boolean b;

    // Convert the string into a boolean
    if (sValue.compareTo("TRUE") == 0) {
      b = true;
    }
    else if (sValue.compareTo("ON") == 0) {
      b = true;
    }
    else if (sValue.compareTo("YES") == 0) {
      b = true;
    }
    else if (sValue.compareTo("NORMAL") == 0) {
      b = true;
    }
    else {
      b = false;
    }

    return b;
  }

//----------------------------------------------------------------------------

  /**
   * Loads the .ini file into an internal vector to cache it in
   * memory.
   *
   * @since           JDK1.2
   */
  private synchronized void loadCache() {

    String thisLine;

    //Clear the current cache
    iniCache.clear();

    if (this.cached) {
      try {
        //Do not allow other threads to read from the input
        //or write to the output while this is taking place
        LineNumberReader ini = new LineNumberReader(
                                 new FileReader(this.iniFilename));

        //Loop through each line and add non-blank
        //lines to the Vector
        while ((thisLine = ini.readLine()) != null) {
          iniCache.add(thisLine.trim());
        }

        ini.close();
      } catch (IOException e) { }
    }
  }

//----------------------------------------------------------------------------

  /**
   * Returns a String that contains the value for a specified key.
   *
   * @param section       the name of the section in the <code>.ini</code>
   *                      file.
   * @param key           the name of the key in the <code>.ini</code> file.
   * @param defaultValue  the default value for the key.
   * @return              a String that contains the value for the specified
   *                      key
   * @since               JDK1.2
   */
  public String getSetting(String section, String key, String defaultValue) {

    String currentLine      = new String("");
    String currentSection   = new String("");
    String currentKey       = new String("");
    String currentValue     = new String("");

    //If it's cached
    if (this.cached) {

      //Loop through the vector
      for (int i = 0; i < this.iniCache.size(); i++) {

        //Get the current line of text
        currentLine = this.iniCache.elementAt(i).toString();
        //If it's an empty line
        if (currentLine.trim().length() > 0) {
          if (debugOn){
            //System.out.println("Reading line:"+currentLine);
          }

          //If it's a section
          if (currentLine.trim().substring(0, 5).compareTo("rem [") == 0) {
            if (debugOn){
               //System.out.println("Begin Section!");
            }

            //Get the setion name
            String s = currentLine.trim();
            currentSection = s.substring(5, s.length() - 1);
            currentKey = "";
            currentValue = "";

          //If it's a key
          } else if (this.inString(currentLine, "=", 1) > 1) {

            //Get the key name
            currentKey = currentLine.substring(0,
              this.inString(currentLine, "=", 1) - 1);

            //Get the value
            currentValue = currentLine.substring(currentKey.length() + 1);
          }
        } else {

          //no values for this line
          currentLine = "";
          currentValue = "";
        }

        //If we have a match, stop the loop
        if ((currentSection.compareToIgnoreCase(section) == 0) &&
            (currentKey.compareToIgnoreCase(key) == 0)) {
          break;
        }

      }//next

    //It's not cached
    } else {

      try {

        //Open the file
        LineNumberReader ini = new LineNumberReader(
                                 new FileReader(this.iniFilename));
        boolean doContinue = true;

        synchronized (ini) {
          while (doContinue) {

            //Get the current line of text
            if ((currentLine = ini.readLine()) == null) {
              currentLine = "";
              currentValue = "";
              doContinue = false;
            } else {
              //If it's an empty line
              if (currentLine.trim().length() > 0) {
                if (debugOn){
                  //System.out.println("Reading line:"+currentLine);
                }
                //If it's a section
                if (currentLine.trim().substring(0, 5).compareTo("rem [") == 0) { // was substring(0, 1).compareTo("[")
                  if (debugOn){
                     //System.out.println("Begin Section!");
                  }
                  //Get the setion name
                  String s = currentLine.trim();
                  currentSection = s.substring(5, s.length() - 1); //was s.substring(1, s.length() - 1);
                  currentKey = "";
                  currentValue = "";

                //If it's a key
                } else if (this.inString(currentLine, "=", 1) > 1) {

                  //Get the key name
                  currentKey = currentLine.substring(0,
                    this.inString(currentLine, "=", 1) - 1);

                  //Get the value
                  currentValue =
                    currentLine.substring(currentKey.length() + 1);
                  if (debugOn){
                     //System.out.println("Key: "+currentKey+"="+currentValue);
                  }
                }
              } else {

                //no values for this line
                currentLine = "";
                currentValue = "";
              }

              //If we have a match, stop the loop
              if ((currentSection.compareToIgnoreCase(section) == 0) &&
                  (currentKey.compareToIgnoreCase(key) == 0)) {
                doContinue = false;
              }

            }

          }//loop
        }//end sync

      }
      catch (IOException e) {
        currentValue = "";
      }
    }

    //If there was no setting found, use the default instead
    if (currentValue.trim().compareTo("") == 0) {
      currentValue = defaultValue;
    }

    //Send back the value
    if (debugOn) {
      System.out.println("Value readed (section:"+section+", key:"+key+", default:"+defaultValue+"):"+currentValue);
    }
    return currentValue;
  }

//----------------------------------------------------------------------------

  /**
   * Sets a value for a specified key. This temporarily loads the entire
   * <code>.ini</code> file into memory if it is not already cached. If
   * the file is cached, the change is only in memory until the
   * <code>flush()</code> method is called. If the file is not cached,
   * then writes happen immediately.
   *
   * @param section   the section in the <code>.ini</code> file
   * @param key       the name of the key to change
   * @param value     the String value to change the key to
   * @since           JDK1.2
   */
  public void setSetting(String section, String key, String value) {

    //If the .ini file is cached in memory
    if (this.cached) {
      setSettingCached(section, key, value);

    //The .ini file is not cached in memory
    } else {
      this.cached = true;
      this.loadCache();
      this.setSettingCached(section, key, value);
      this.flush();
      this.setCachedState(false);
    }
  }

//----------------------------------------------------------------------------

  /**
   * Saves the cached <code>.ini</code> information back out to the
   * <code>.ini</code> file. This method is only available when caching
   * is turned on. Otherwise, it does nothing. If you do not call this
   * method when caching is turned on, your changes will not be saved.
   *
   * @since           JDK1.2
   */
  public synchronized void flush() {

    if (this.cached) {

      try {
        //Do not allow other threads to read from the input
        //or write to the output while this is taking place
        FileWriter ini = new FileWriter(this.iniFilename);
        // Loop through the vector
        for (int i = 0; i < this.iniCache.size(); i++) {

          //Write out each line
          ini.write(iniCache.elementAt(i).toString());

          //If this is not the last line of the file
          if (i < (this.iniCache.size() - 1)) {

            //Append a carriage return and line feed
            ini.write(13);
            ini.write(10);

          }
        }

        //Write out and close
        ini.flush();
        ini.close();

        if (debugOn){
          System.out.println("IniFile saved!");
        }
      } catch (IOException e) { }
    }
  }

//----------------------------------------------------------------------------

  /**
   * Sets a value for a specified key in the cached Vector object
   *
   * @param key       the name of the key to change
   * @param value     the String value to change the key to
   * @since           JDK1.2
   */
  private void setSettingCached(String section, String key, String value) {

    String currentLine      = new String("");
    String currentSection   = new String("");
    String currentKey       = new String("");
    String currentValue     = new String("");
    String lastLine         = new String("");
    String lastSection      = new String("");
    boolean madeUpdate      = false;

    if (debugOn){
      System.out.println("Setting in IniFile: ["+section+"], "+key+":"+value);
    }

    //Loop through the vector
    for (int i = 0; i < this.iniCache.size(); i++) {

      //Get the current line of text
      lastLine = currentLine;
      lastSection = currentSection;
      currentLine = this.iniCache.elementAt(i).toString();

      //If it's an empty line
      if (currentLine.trim().length() > 0) {

        //If it's a section
        if (currentLine.trim().substring(0, 5).compareTo("rem [") == 0) {

          //Get the setion name
          String s = currentLine.trim();
          currentSection = s.substring(5, s.length() - 1);
          currentKey = "";
          currentValue = "";

        //If it's a key
        } else if (this.inString(currentLine, "=", 1) > 1) {

          //Get the key name
          currentKey = currentLine.substring(0,
            this.inString(currentLine, "=", 1) - 1);

          //Get the value
          currentValue = currentLine.substring(currentKey.length() + 1);
        }
      } else {

        //no values for this line
        currentLine = "";
        currentValue = "";
      }

      //If the last section matches
      if (lastSection.compareToIgnoreCase(section) == 0) {

        //Is this the correct key line?
        if (currentKey.compareToIgnoreCase(key) == 0) {

          //Insert the new line
          iniCache.remove(i);
          iniCache.insertElementAt(new String(currentKey + "=" + value), i);
          madeUpdate = true;
          break;

        //Is the section different now?
        } else if (currentSection.compareToIgnoreCase(section) != 0) {

          //Insert the new line and a blank line
          iniCache.insertElementAt(new String(key + "=" + value), i - 1);
          iniCache.insertElementAt(new String(""), i);
          madeUpdate = true;
          break;

        //Is the current line blank?
        } else if (currentLine.trim().length() == 0) {

          //Insert the new line
          iniCache.insertElementAt(new String(key + "=" + value), i);
          madeUpdate = true;
          break;

        //Is this the last line of the file?
        } else if (i == (this.iniCache.size() - 1)) {

          //Add the new line
          iniCache.add(new String(key + "=" + value));
          madeUpdate = true;
          break;

        }
      }
    }//next

    //If we didn't find the section, we'll make a new one
    if (!madeUpdate) {

      //If there's not a blank line, skip one line
      if (currentLine.trim().length() > 0) {

        //Write a blank line
        iniCache.add(new String(""));

      }

      //Write the section
      iniCache.add(new String("rem [" + section + "]"));

      //Write the new line
      iniCache.add(new String(key + "=" + value));
      if (debugOn){
          System.out.println(" Creating a new one");
       }

    } else {
        if (debugOn){
          System.out.println(" Set done");
        }
    }
  }

}
